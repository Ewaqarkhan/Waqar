/* Mobile navigation toggle */
(function () {
  var button = document.querySelector('.greedy-nav button');
  var links = document.querySelector('.greedy-nav .visible-links');
  if (button && links) {
    button.addEventListener('click', function () {
      links.classList.toggle('is-open');
    });
  }
})();
